running experiments: python launcher.py
plotting results: python plotting.py
